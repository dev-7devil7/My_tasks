# -*- coding: utf-8 -*-

"""General utilities for Powertools"""
